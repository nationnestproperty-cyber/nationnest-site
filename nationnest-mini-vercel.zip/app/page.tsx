export default function Page(){
  return (
    <main style={{maxWidth:960,margin:'40px auto',padding:'0 16px'}}>
      <h1 style={{fontSize:32,fontWeight:700}}>NationNest Property</h1>
      <p>เว็บไซต์เดโม พร้อมเชื่อมฐานข้อมูล Postgres บน Vercel (auto migrate + seed).</p>
      <p>หลัง deploy: เปิด <code>/admin/login</code> เพื่อเข้าสู่ระบบ</p>
    </main>
  );
}
